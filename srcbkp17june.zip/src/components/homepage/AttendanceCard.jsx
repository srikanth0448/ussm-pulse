import { CalendarDays } from "lucide-react";
import "./Attendence.css";

export default function AttendanceCard() {
  return (
    <div className="attendance-card">
      {/* Header */}
      <div className="attendance-card__header">
        <div className="attendance-card__date">
          <CalendarDays size={20} />
          <span>05 Jun 2026</span>
        </div>

        <div className="attendance-card__status">
          PRESENT
        </div>
      </div>

      {/* Content */}
      <div className="attendance-card__content">
        <div className="attendance-card__body">
          <div className="attendance-card__item">
            <span className="attendance-card__label">
              Clock-In :
            </span>
            <span className="attendance-card__value">
              10:51 am
            </span>
          </div>

          <div className="attendance-card__divider" />

          <div className="attendance-card__item">
            <span className="attendance-card__label">
              Late By :
            </span>
            <span className="attendance-card__value">
              00:00
            </span>
          </div>

          <div className="attendance-card__divider" />

          <div className="attendance-card__item">
            <span className="attendance-card__label">
              Clock-Out :       
            </span>
            <span className="attendance-card__value">
              00:00
            </span>
          </div>

          <div className="attendance-card__divider" />

          <div className="attendance-card__item">
            <span className="attendance-card__label">
              Productive Hrs.
            </span>
            <span className="attendance-card__value">
              00:00
            </span>
          </div>
        </div>

        <div className="attendance-card__action">
          <button className="attendance-card__btn">
            Out
          </button>
        </div>
      </div>
    </div>
  );
}