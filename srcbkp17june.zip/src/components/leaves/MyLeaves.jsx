import React, { useEffect, useState } from "react";
import {
  Container,
  Row,
  Col,
  Table,
  Card,
  Button,
  Form,
  Spinner,
  InputGroup,
  Pagination,
  Modal,
} from "react-bootstrap";
import {
  FaEye,
  FaEyeSlash,
  FaEdit,
  FaTimesCircle,
  FaSyncAlt,
  FaPlus,
  FaArrowRight,
} from "react-icons/fa";
import { BsFillEyeFill, BsFillEyeSlashFill } from "react-icons/bs";
import { useMyLeaves } from "../../hooks/useMyLeaves";

export default function MyLeaves() {
  const { leaves, loading, error, refreshLeaves } = useMyLeaves();

  const [statusFilter, setStatusFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [expandedRow, setExpandedRow] = useState(null);

  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 10;

  // Modal and form state for Apply Leave
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    leaveType: "",
    leaveFor: "Full Day",
    fromDate: "",
    toDate: "",
    noOfDays: "",
    reason: "",
  });

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleApplySubmit = (e) => {
    e.preventDefault();
    // TODO: call API to submit leave. For now just log and close modal.
    console.log("Apply Leave submitted:", form);
    closeModal();
    // Optionally refresh leaves after applying
    if (typeof refreshLeaves === "function") refreshLeaves();
  };

  const toggleDetails = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  const formatDate = (date) => {
    if (!date) return "-";

    const d = new Date(date);

    const day = String(d.getDate()).padStart(2, "0");

    const month = d.toLocaleString("en-GB", {
      month: "short",
    });

    const year = d.getFullYear();

    return `${day}-${month}-${year}`;
  };

  const getLeaveTypeShort = (leaveType) => {
    const type = (leaveType || "").toLowerCase().trim();

    switch (type) {
      case "casual leave":
        return "CL";

      case "sick leave":
        return "SL";

      case "loss of pay":
        return "LOP";

      case "earned leave":
        return "EL";

      case "maternity leave":
        return "ML";

      case "paternity leave":
        return "PL";

      case "work from home":
        return "WFH";

      case "compensatory off":
        return "COff";

      case "leave without pay":
        return "LWP";

      case "optional holiday":
        return "OH";

      default:
        return leaveType;
    }
  };

  const getStatusBadge = (status) => {
    const normalizedStatus = (status || "").toLowerCase();

    switch (normalizedStatus) {
      case "approved":
        return "success";

      case "pending":
        return "warning";

      case "rejected":
        return "danger";

      case "cancelled":
        return "secondary";

      default:
        return "secondary";
    }
  };

  const filtered = leaves.filter((leave) => {
    if (
      statusFilter !== "All" &&
      (leave.status_text || "").toLowerCase() !== statusFilter.toLowerCase()
    ) {
      return false;
    }

    if (!search) return true;

    const searchText = search.toLowerCase();

    return (
      (leave.leave_type_text || "").toLowerCase().includes(searchText) ||
      (leave.reason || "").toLowerCase().includes(searchText)
    );
  });

  const totalPages = Math.ceil(filtered.length / recordsPerPage);

  const indexOfLastRecord = currentPage * recordsPerPage;

  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;

  const currentRecords = filtered.slice(indexOfFirstRecord, indexOfLastRecord);

  useEffect(() => {
    setCurrentPage(1);
  }, [search, statusFilter]);

  return (
    <Container className="p-0">
      {/* Header */}
      <Row className="align-items-center mb-3">
        <Col xs={6}>
          <h5 className="mb-0">My Leaves</h5>
        </Col>

        <Col xs={6} className="text-end">
          <Button variant="success" size="sm" onClick={openModal}>
            <FaPlus className="me-1" />
            Apply Leave
          </Button>
        </Col>
      </Row>

      {/* Apply Leave Modal */}
      <Modal show={showModal} onHide={closeModal} centered size="lg">
        <Form onSubmit={handleApplySubmit}>
          <Modal.Header closeButton>
            <Modal.Title>Apply Leave</Modal.Title>
          </Modal.Header>

          <Modal.Body>
            <Row className="g-3">
              <Col md={6}>
                <Form.Group>
                  <Form.Label>
                    Leave Type <span className="text-danger">*</span>
                  </Form.Label>
                  <Form.Select
                    name="leaveType"
                    value={form.leaveType}
                    onChange={handleFormChange}
                  >
                    <option value="">Select Leave Type</option>
                    <option value="9">Casual Leave</option>
                    <option value="11">Leave Without Pay</option>
                    <option value="12">Compensatory Off</option>
                    <option value="13">Optional Holiday</option>
                    <option value="209">Maternity Leave</option>
                  </Form.Select>
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group>
                  <Form.Label>
                    Leave For<span className="text-danger">*</span>
                  </Form.Label>
                  <Form.Select
                    name="leaveFor"
                    value={form.leaveFor}
                    onChange={handleFormChange}
                  >
                    <option value="Full Day">Full Day</option>
                    <option value="Half Day">Half Day</option>
                  </Form.Select>
                </Form.Group>
              </Col>

              <Col md={4}>
                <Form.Group>
                  <Form.Label>
                    From<span className="text-danger">*</span>
                  </Form.Label>
                  <Form.Control
                    type="date"
                    name="fromDate"
                    value={form.fromDate}
                    onChange={handleFormChange}
                  />
                </Form.Group>
              </Col>

              <Col md={4}>
                <Form.Group>
                  <Form.Label>
                    To<span className="text-danger">*</span>
                  </Form.Label>
                  <Form.Control
                    type="date"
                    name="toDate"
                    value={form.toDate}
                    onChange={handleFormChange}
                  />
                </Form.Group>
              </Col>

              <Col md={4}>
                <Form.Group>
                  <Form.Label>
                    No Of Days<span className="text-danger">*</span>
                  </Form.Label>
                  <Form.Control
                    type="number"
                    min="0"
                    name="noOfDays"
                    value={form.noOfDays}
                    onChange={handleFormChange}
                  />
                </Form.Group>
              </Col>

              <Col xs={12}>
                <Form.Group>
                  <Form.Label>Reason</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={4}
                    name="reason"
                    value={form.reason}
                    onChange={handleFormChange}
                    placeholder="Enter Reason"
                  />
                </Form.Group>
              </Col>
            </Row>
          </Modal.Body>

          <Modal.Footer>
            <Button variant="secondary" onClick={closeModal}>
              Close
            </Button>

            <Button variant="success" type="submit">
              Apply Leave <FaArrowRight className="ms-2" />
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Filters */}
      <Row className="mb-3 g-2">
        <Col xs={12} md={4}>
          <Form.Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="All">All Status</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
            <option value="Cancelled">Cancelled</option>
          </Form.Select>
        </Col>
      </Row>

      {/* Error */}
      {error && (
        <Card bg="danger" text="white" className="mb-3">
          <Card.Body>{error}</Card.Body>
        </Card>
      )}

      {/* Desktop View */}
      <div className="d-none d-md-block">
        <Table striped bordered hover responsive className="align-middle">
          <thead>
            <tr>
              <th>ID</th>
              <th>Leave Type</th>
              <th>From Date</th>
              <th>To Date</th>
              <th>No Of Days</th>
              <th>Reason</th>
              <th>Status</th>
              <th width="150">Actions</th>
            </tr>
          </thead>

          <tbody>
            {loading && filtered.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center">
                  <Spinner animation="border" />
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center">
                  No records found
                </td>
              </tr>
            ) : (
              currentRecords?.map((leave) => (
                <tr key={leave.leave_id}>
                  <td>{leave.leave_id}</td>
                  <td>{leave.leave_type_text}</td>
                  <td>{formatDate(leave.from_date)}</td>
                  <td>{formatDate(leave.to_date)}</td>
                  <td>{leave.no_of_days}</td>
                  <td>{leave.reason || "-"}</td>

                  <td>
                    <span
                      className={`badge bg-${getStatusBadge(
                        leave.status_text,
                      )}`}
                    >
                      {leave.status_text}
                    </span>
                  </td>

                  <td>
                    <div className="d-flex gap-1">
                      {leave.is_edit_icon_show === 1 && (
                        <Button size="sm" variant="outline-primary">
                          <FaEdit />
                        </Button>
                      )}

                      {leave.is_cancel_icon_show === 1 && (
                        <Button size="sm" variant="outline-danger">
                          <FaTimesCircle />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </Table>
      </div>

      {/* Mobile View */}
      <div className="d-block d-md-none">
        {loading && filtered.length === 0 ? (
          <div className="text-center py-4">
            <Spinner animation="border" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-4">No records found</div>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <Table bordered hover size="sm" className="align-middle">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Duration</th>
                  <th>Days</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>

              <tbody>
                {currentRecords?.map((leave) => (
                  <React.Fragment key={leave.leave_id}>
                    <tr>
                      <td className="text-center">
                        {getLeaveTypeShort(leave.leave_type_text)}
                      </td>

                      <td>
                        <div>{formatDate(leave.from_date)}</div>

                        {formatDate(leave.to_date)}
                      </td>

                      <td className="text-center">{leave.no_of_days}</td>

                      <td>
                        <span
                          className={`badge bg-${getStatusBadge(
                            leave.status_text,
                          )}`}
                          style={{ fontWeight: 400 }}
                        >
                          {leave.status_text}
                        </span>
                      </td>

                      <td>
                        <span onClick={() => toggleDetails(leave.leave_id)}>
                          {expandedRow === leave.leave_id ? (
                            <BsFillEyeSlashFill />
                          ) : (
                            <BsFillEyeFill />
                          )}
                        </span>
                      </td>
                    </tr>

                    {expandedRow === leave.leave_id && (
                      <tr>
                        <td colSpan="5" className="bg-light">
                          <div className="p-2">
                            <Row className="mb-2">
                              <Col xs={4}>
                                <strong>Leave</strong>
                              </Col>
                              <Col xs={8}>{leave.leave_type_text}</Col>
                            </Row>

                            <Row className="mb-2">
                              <Col xs={4}>
                                <strong>Start Date</strong>
                              </Col>
                              <Col xs={8}>{formatDate(leave.from_date)}</Col>
                            </Row>

                            <Row className="mb-2">
                              <Col xs={4}>
                                <strong>End Date</strong>
                              </Col>
                              <Col xs={8}>{formatDate(leave.to_date)}</Col>
                            </Row>

                            <Row className="mb-2">
                              <Col xs={4}>
                                <strong>No. of Days</strong>
                              </Col>
                              <Col xs={8}>{leave.no_of_days}</Col>
                            </Row>

                            <Row className="mb-2">
                              <Col xs={4}>
                                <strong>Reason</strong>
                              </Col>
                              <Col xs={8}>{leave.reason || "-"}</Col>
                            </Row>

                            <div className="mt-3 d-flex gap-2">
                              {leave.is_edit_icon_show === 1 && (
                                <Button size="sm" variant="primary">
                                  <FaEdit className="me-1" />
                                  Edit
                                </Button>
                              )}

                              {leave.is_cancel_icon_show === 1 && (
                                <Button size="sm" variant="danger">
                                  <FaTimesCircle className="me-1" />
                                  Cancel
                                </Button>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
            <div className="text-center text-muted mb-2">
              Showing {indexOfFirstRecord + 1} -
              {Math.min(indexOfLastRecord, filtered.length)} of{" "}
              {filtered.length} records
            </div>
            {totalPages > 1 && (
              <Row className="mt-3">
                <Col>
                  <div className="d-flex justify-content-center">
                    <Pagination>
                      <Pagination.First
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(1)}
                      />

                      <Pagination.Prev
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage((prev) => prev - 1)}
                      />

                      {[...Array(totalPages)].map((_, index) => (
                        <Pagination.Item
                          key={index + 1}
                          active={currentPage === index + 1}
                          onClick={() => setCurrentPage(index + 1)}
                        >
                          {index + 1}
                        </Pagination.Item>
                      ))}

                      <Pagination.Next
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage((prev) => prev + 1)}
                      />

                      <Pagination.Last
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage(totalPages)}
                      />
                    </Pagination>
                  </div>
                </Col>
              </Row>
            )}
          </div>
        )}
      </div>
    </Container>
  );
}
