import AttendanceRow from "../attendance/AttendanceRow";

import "../../styles/attendance.css";

export default function AttendanceTable({
  attendanceData,
}) {
  return (
    <div className="attendance-table">
      {attendanceData.map((item, index) => (
        <AttendanceRow
          key={index}
          item={item}
        />
      ))}
    </div>
  );
}