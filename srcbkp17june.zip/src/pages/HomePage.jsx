import"../styles/Homepage.css";
import LocationCard from "../components/homepage/LocationCard";
import AttendanceCard from "../components/homepage/AttendanceCard";


function HomePage() {

  return (
    <div className="HomePage-Section">
      <LocationCard />
      <AttendanceCard />
    </div>
  );
}

export default HomePage;
