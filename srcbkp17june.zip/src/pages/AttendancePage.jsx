import { useState } from "react";
import AttendanceSummary from "../components/attendance/AttendanceSummary";
import AttendanceHeader from "../components/attendance/AttendanceHeader";
import AttendanceMonthPicker from "../components/attendance/AttendanceMonthPicker";
import AttendanceTable from "../components/attendance/AttendanceTable";

function AttendancePage() {
   const [selectedMonth, setSelectedMonth] = useState(
    new Date().toISOString().slice(0, 7)
  );



  const attendanceData = [];

  return (
    <>
      <AttendanceHeader />

        <AttendanceMonthPicker
        selectedMonth={selectedMonth}
        onMonthChange={setSelectedMonth}
      />
      <AttendanceSummary
        monthYear={selectedMonth}
      />

      <AttendanceTable attendanceData={attendanceData} />
    </>
  );
}

export default AttendancePage;