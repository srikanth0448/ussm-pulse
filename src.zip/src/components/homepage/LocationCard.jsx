import { MapPin } from "lucide-react";
import "./LocationCard.css";

export default function LocationCard() {
  return (
    
    <div className="location-card">
      <div className="location-card__content">
        <div className="location-card__icon">
          <MapPin size={20} />
        </div>

        <div className="location-card__details">
          <h3 className="location-card__title">
            Now, You Are At:
          </h3>

          <p className="location-card__address">
            270/E, Road Number 10, Gayatri Hills,
            Jubilee Hills, Hyderabad,
            Telangana 500045, India
          </p>
        </div>
      </div>

      
    </div>
    
  );
}