import { useEffect, useState } from "react";
import { getMonthlyAttendance } from "../../services/attendanceService";
import "./MonthlyAttendance.css";

function MonthlyAttendance() {
  const [month, setMonth] = useState(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, "0");
    return `${y}-${m}`;
  });
  const [status, setStatus] = useState("All");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const resp = await getMonthlyAttendance(`${month}`);
      if (resp && resp.data && resp.data.attendance_monthly_info) {
        setData(resp.data.attendance_monthly_info);
      } else {
        setData([]);
      }
    } catch (err) {
      setError(err.message || "Failed to fetch");
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSearch = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="monthly-attendance">
      <form className="controls" onSubmit={onSearch}>
        <div className="control-item">
          <label>Month</label>
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
          />
        </div>

        <div className="control-item">
          <label>Employee Status</label>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option>All</option>
            <option>Present</option>
            <option>Absent</option>
            <option>WeekOff</option>
            <option>WFH</option>
          </select>
        </div>

        <div className="control-actions">
          <button type="submit" className="btn primary">
            Search
          </button>
        </div>
      </form>

      <div className="table-wrap">
        {loading && <div className="loading">Loading...</div>}
        {error && <div className="error">{error}</div>}

        <table className="attendance-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Emp ID</th>
              <th>Name</th>
              <th>Department</th>
              <th>Designation</th>
              <th>Total Days</th>
              <th>Present</th>
              <th>Absent</th>
              <th>Casual Leave</th>
              <th>LOP</th>
              <th>CO</th>
              <th>OD</th>
              <th>Week Off</th>
              <th>WFH</th>
              <th>Short Leave</th>
              <th>Holiday</th>
              <th>Paid Days</th>
            </tr>
          </thead>
          <tbody>
            {data && data.length ? (
              data
                .filter((row) => {
                  if (status === "All") return true;
                  if (status === "Present") return Number(row.present) > 0;
                  if (status === "Absent") return Number(row.absent) > 0;
                  if (status === "WeekOff") return Number(row.week_off) > 0;
                  if (status === "WFH") return Number(row.wfh) > 0;
                  return true;
                })
                .map((row, idx) => (
                  <tr key={row.user_id || idx}>
                    <td>{idx + 1}</td>
                    <td>{row.emp_id}</td>
                    <td>{row.emp_name}</td>
                    <td>{row.department_name}</td>
                    <td>{row.designation_name}</td>
                    <td>{row.total_days}</td>
                    <td>{row.present}</td>
                    <td>{row.absent}</td>
                    <td>{row.casual_leave}</td>
                    <td>{row.lop}</td>
                    <td>{row.co}</td>
                    <td>{row.od}</td>
                    <td>{row.week_off}</td>
                    <td>{row.wfh}</td>
                    <td>{row.short_leave}</td>
                    <td>{row.holiday}</td>
                    <td>{row.paid_days}</td>
                  </tr>
                ))
            ) : (
              <tr>
                <td colSpan={17} className="no-data">
                  No records found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default MonthlyAttendance;
