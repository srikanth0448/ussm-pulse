import { api } from "../api/axiosClient";

export const leaveService = {
  getMyLeaves: () => api.get("/my-leaves"),

  // params should be an object with keys matching backend query params
  // e.g. { leave_type, leave_for, from_date, to_date, num_of_days, worked_on }
  applyLeave: (params) =>
    api.post(
      `/apply-leave?leave_type=${params.leave_type}&leave_for=${params.leave_for}&from_date=${params.from_date}&to_date=${params.to_date}&num_of_days=${params.num_of_days}&worked_on=${params.worked_on}&comp_off=${params.comp_off}&optional_holiday_type=${params.optional_holiday_type}&latitude=${params.latitude}&longitude=${params.longitude}`,
    ),
};
