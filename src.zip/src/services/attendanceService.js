import { api } from "../api/axiosClient";

const getMonthlyAttendance = (monthYear) => {
  return api.get("/emp-attendance-monthly-info", {
    params: { month_year: monthYear },
  });
};

export { getMonthlyAttendance };
