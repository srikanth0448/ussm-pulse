import MonthlyAttendance from "../components/attendance/MonthlyAttendance";

function AttendancePage() {
  return (
    <div className="attendance-page">
      <h1>Attendance</h1>
      <MonthlyAttendance />
    </div>
  );
}

export default AttendancePage;
