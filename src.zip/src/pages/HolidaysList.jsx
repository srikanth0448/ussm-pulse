import { useEffect, useState } from "react";
import HolidaySection from "../components/holidays/HolidaySection";
import "../components/holidays/Holidays.css";
import { api } from "../api/axiosClient";
import { CalendarDays,ChevronDown } from "lucide-react";
import Loader from "../components/common/Loader"

export default function HolidaysList() {
  const [holidayData, setHolidayData] = useState(null);
  const [selectedYear, setSelectedYear] = useState(2025);

  useEffect(() => {
    getHolidayList(selectedYear);
  }, []);

const getHolidayList = async (year) => {
  try {
    const { data } = await api.post(
      `/holidays-list?year=${year}`
    );

    console.log("Holiday Data:", data);

    setHolidayData(data);
  } catch (error) {
    console.log("Holiday API Error:", error);
  }
};


  if (!holidayData) {
    return (
    <Loader/>
    );
  }

  const handleYearChange = (e) => {
    const year = e.target.value;
    setSelectedYear(year);
    getHolidayList(year);
  };

  return (
    <div className="holidays-page">
      <div className="holidays-page__header">
        <h1 className="pageheader">Holidays</h1>

        
      <div className="calender-datesection">
        <CalendarDays className="calendar-icon" size={17} color="#0b61df" />
              <select
                value={selectedYear}
                onChange={handleYearChange}
                className="holidays-page__select"  >
                {holidayData?.years?.map((year) => (
                  <option
                    key={year}
                    value={year}
                  >
                    {year}
                  </option>
                ))}
              </select>
               <ChevronDown className="dropdown-icon" size={16} />
         </div>
      </div>

      <HolidaySection
        title="Fixed Holidays"
        holidays={
          holidayData?.data?.fixed_holidays || []
        }
      />

      <HolidaySection
        isOptional={false}
        title="Optional Holidays (any 2)"
        holidays={holidayData?.data?.optional_holidays || []}
        isOptional={true}
      />
    </div>
  );
}